import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentsSectionComponent } from './payments-section.component';

describe('PaymentsSectionComponent', () => {
  let component: PaymentsSectionComponent;
  let fixture: ComponentFixture<PaymentsSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentsSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentsSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
