import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payments-section',
  templateUrl: './payments-section.component.html',
  styleUrls: ['./payments-section.component.scss']
})
export class PaymentsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
