import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-section',
  templateUrl: './order-section.component.html',
  styleUrls: ['./order-section.component.scss'],
})
export class OrderSectionComponent implements OnInit {
  showPayments: Boolean = true;
  constructor() {}

  ngOnInit() {}
}
