import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-ex',
  templateUrl: './footer-ex.component.html',
  styleUrls: ['./footer-ex.component.scss']
})
export class FooterExComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
